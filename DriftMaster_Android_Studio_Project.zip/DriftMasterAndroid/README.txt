DRIFT MASTER - Android Studio project

IMPORTANT:
This is the Android app source project, not a precompiled APK.
It needs to be built with Android Studio on a computer.

Build:
1. Install Android Studio.
2. Extract this ZIP.
3. In Android Studio choose Open and select the DriftMaster folder.
4. Let Gradle sync and install the requested Android SDK (API 35).
5. Connect an Android phone with USB debugging enabled.
6. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio will show the APK location.

Phone setup:
1. Upload the ESP32 BluetoothSerial firmware from the accompanying conversation.
2. Turn on Bluetooth on the phone.
3. Pair with ESP32_DRIFT_CAR in Android Bluetooth settings.
4. Open DRIFT MASTER, select the paired ESP32 and tap CONNECT.

Bluetooth compatibility:
This app uses Bluetooth Classic Serial Port Profile (SPP). It requires a classic ESP32
that supports BluetoothSerial. ESP32-C3, ESP32-S3 and some newer variants do not
support Bluetooth Classic SPP.

Firmware compatibility:
The app sends F, B, L, R and S for movement, and 1, 2, 3 for low/medium/high speed.
Your ESP32 firmware must implement those exact commands.

Safety:
Test with the wheels lifted off the ground first. Secure the car, use a correctly
protected battery pack, and verify motor/driver voltage and current ratings.
The app sends STOP when a direction button is released, but do not rely on the app
as the only safety mechanism.
