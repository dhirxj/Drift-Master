package com.driftmaster.controller

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val sppUuid: UUID =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var connectButton: Button
    private lateinit var speedLabel: TextView
    private var pairedDevices: List<BluetoothDevice> = emptyList()
    private var connected = false
    private val requestBluetoothPermission = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        refreshPairedDevices()
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 24, 22, 20)
            setBackgroundColor(0xFF101820.toInt())
        }

        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            }
        }

        root.addView(text("DRIFT MASTER", 27f, 0xFFFFFFFF.toInt(), true))
        root.addView(text("ESP32 BLUETOOTH CONTROLLER", 11f, 0xFF9FB3C8.toInt()).apply {
            setPadding(0, 4, 0, 18)
        })

        status = text("Not connected", 14f, 0xFFFFC857.toInt(), true)
        root.addView(status)

        deviceSpinner = Spinner(this)
        root.addView(deviceSpinner, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 52
        ).apply { topMargin = 12 })

        val refresh = Button(this).apply {
            text = "REFRESH PAIRED DEVICES"
            setOnClickListener { refreshPairedDevices() }
        }
        root.addView(refresh)

        connectButton = Button(this).apply {
            text = "CONNECT"
            setOnClickListener {
                if (connected) disconnectCar() else connectCar()
            }
        }
        root.addView(connectButton)

        speedLabel = text("SPEED: MEDIUM", 15f, 0xFFFFFFFF.toInt(), true).apply {
            setPadding(0, 18, 0, 0)
        }
        root.addView(speedLabel)

        val speed = SeekBar(this).apply {
            max = 2
            progress = 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    val command = when (value) {
                        0 -> "1"
                        1 -> "2"
                        else -> "3"
                    }
                    speedLabel.text = when (value) {
                        0 -> "SPEED: LOW"
                        1 -> "SPEED: MEDIUM"
                        else -> "SPEED: HIGH"
                    }
                    if (fromUser) send(command)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(speed, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 48
        ))

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 10, 1f))

        val up = controlButton("▲", "F")
        root.addView(up, buttonParams())

        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        middle.addView(controlButton("◀", "L"), buttonParams(0, 1f))
        middle.addView(Button(this).apply {
            text = "STOP"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFFB83232.toInt())
            setOnClickListener { send("S") }
        }, buttonParams(8, 1f))
        middle.addView(controlButton("▶", "R"), buttonParams(0, 1f))
        root.addView(middle)

        root.addView(controlButton("▼", "B"), buttonParams())

        root.addView(text(
            "Hold a direction to drive; release to stop.",
            12f, 0xFF9FB3C8.toInt()
        ).apply { setPadding(0, 16, 0, 0) })

        setContentView(root)
    }

    private fun buttonParams(top: Int = 7, weight: Float = 0f): LinearLayout.LayoutParams {
        return if (weight > 0f) {
            LinearLayout.LayoutParams(0, 64, weight).apply {
                setMargins(5, top, 5, 5)
            }
        } else {
            LinearLayout.LayoutParams(112, 64).apply {
                topMargin = top
                bottomMargin = 5
            }
        }
    }

    private fun controlButton(label: String, command: String): Button {
        return Button(this).apply {
            text = label
            textSize = 25f
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> send(command)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> send("S")
                }
                true
            }
        }
    }

    private fun hasBluetoothPermission(): Boolean {
        return Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestBtPermissionIfNeeded(): Boolean {
        if (Build.VERSION.SDK_INT >= 31 && !hasBluetoothPermission()) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), requestBluetoothPermission)
            return false
        }
        return true
    }

    private fun refreshPairedDevices() {
        if (!requestBtPermissionIfNeeded()) return
        try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null) {
                status.text = "This phone has no Bluetooth adapter"
                return
            }
            if (!adapter.isEnabled) {
                status.text = "Turn on Bluetooth in Android settings"
                return
            }
            pairedDevices = adapter.bondedDevices.toList()
            val names = pairedDevices.map {
                "${it.name ?: "Unknown device"}  (${it.address})"
            }
            deviceSpinner.adapter = ArrayAdapter(
                this, android.R.layout.simple_spinner_dropdown_item,
                if (names.isEmpty()) listOf("No paired devices — pair ESP32 in Settings")
                else names
            )
            status.text = if (pairedDevices.isEmpty())
                "Pair ESP32_DRIFT_CAR in phone Bluetooth settings"
            else "Choose your paired ESP32"
        } catch (e: SecurityException) {
            status.text = "Bluetooth permission required"
        }
    }

    private fun connectCar() {
        if (!requestBtPermissionIfNeeded()) return
        if (pairedDevices.isEmpty()) {
            refreshPairedDevices()
            status.text = "First pair ESP32_DRIFT_CAR in Android Bluetooth settings"
            return
        }
        val index = deviceSpinner.selectedItemPosition
        if (index !in pairedDevices.indices) return
        val device = pairedDevices[index]
        status.text = "Connecting..."
        thread {
            try {
                BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                val newSocket = device.createRfcommSocketToServiceRecord(sppUuid)
                newSocket.connect()
                socket = newSocket
                output = newSocket.outputStream
                connected = true
                runOnUiThread {
                    status.text = "Connected to ${device.name ?: "ESP32"}"
                    connectButton.text = "DISCONNECT"
                }
                send("S")
            } catch (e: Exception) {
                connected = false
                try { socket?.close() } catch (_: Exception) {}
                socket = null
                output = null
                runOnUiThread { status.text = "Connection failed. Check pairing and ESP32 power." }
            }
        }
    }

    private fun send(command: String) {
        thread {
            try {
                output?.write(command.toByteArray(Charsets.US_ASCII))
                output?.flush()
            } catch (_: Exception) {
                runOnUiThread { status.text = "Bluetooth connection lost" }
            }
        }
    }

    private fun disconnectCar() {
        send("S")
        thread {
            try { socket?.close() } catch (_: Exception) {}
            socket = null
            output = null
            connected = false
            runOnUiThread {
                status.text = "Disconnected"
                connectButton.text = "CONNECT"
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestBluetoothPermission &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) refreshPairedDevices()
        else status.text = "Bluetooth permission denied"
    }

    override fun onDestroy() {
        try { output?.write("S".toByteArray()) } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
